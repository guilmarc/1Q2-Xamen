/*
 Votre nom ici :
*/

#include <iostream>
#include <string>
#include <iomanip>
#include <conio.h>
#include <fstream>

using namespace std;

const string FICHIER_PRODUITS = "produits.csv"; //Fichier contenant les produits
const int NOMBRE_PRODUITS = 20;									//Nombre de produits total dans le fichier
const int NOMBRE_ACHATS = 3;										//Nombre fixe d'achats par commande
const int NOMBRE_COMMANDES = 5;									//Nombre de commandes � g�n�rer
const int NOMBRE_PRODUITS_RABAIS = 10;				  //Nombre de produits pour lesquels un rabais sera g�n�r�
const int POURCENTAGE_RABAIS_MINIMAL = 10;			//Pourcentage minimal de rabais pour un produit
const int POURCENTAGE_RABAIS_MAXIMAL = 50;			//Pourcentage maximal de rabais pour un produit
const int QUANTITE_MAXIMALE = 5;								//Quantit� maximale d'un produit dans un Article command�
const int NUMERO_COMMANDE_DEFAUT = 1000;				//Num�ro de commande de d�part
const float POUCENTAGE_TPS = 0.05f;							//Taux de la TPS (taxe sur les produits et services)	
const float POUCENTAGE_TVQ = 0.09975f;					//Taux de la TVQ (taxe de vente du Qu�bec)


/*
 Structure d'un produit
*/
struct Produit {
	string code;				//Code UPS
	string nom;					//Nom du produit
	string description; //Courte description
	float prix = 0;			//Prix de base du produit
	int rabais = 0;			//Rabais applicable en % (exemple 25)
	//TODO: Ajouter une ou des fonction(s) au besoin.
};

/*/
 Tableau global des produits que l'on place ici afin d'y avoir acc�s partout
 dans le code pour simplifier l'examen
*/
Produit produits[NOMBRE_PRODUITS];


/*
 Structure d'une ligne d'achat sur la commande (Exemple : 3 unit�s du produit 123)
*/
struct Achat {
	string code = "";				//Code du produits achet�
	int quantite = 0;				//Quantit� achet�e
	//TODO: Ajouter une ou des fonction(s) au besoin.
};


/*
 Structure d'une commande
*/
struct Commande {
	int numero = 0;
	Achat achats[NOMBRE_ACHATS];
	//TODO: Ajouter une ou des fonction(s) au besoin.
};

/*/
 Tableau global des commandes que l'on place ici afin d'y avoir acc�s partout
 dans le code pour simplifier l'examen
*/
Commande commandes[NOMBRE_COMMANDES];

/*
 Fonction qui attend que l'utilisateur appuie sur la touche ESPACE
*/
void waitForSpaceKey() {
	//TODO: Impl�menter cette fonction
}

/*
 Fonction qui lit les produits � partir du fichier produits.csv
 et les place dans le tableau de produits global
*/
void lireProduits(Produit produits[], int size) {
	//TODO: Impl�menter cette fonction
}

/*
 Fonction retournerProduitHasard qui retourne un produit au hasard parmi
 ceux du tableau.
*/
//TODO: Impl�menter la fonction retournerProduitHasard pour obtenir les
//dernier points disponibles de l'examen seulement (2 pts)


/*
* Fonction qui g�n�re un rabais pour un produit
*/
void genererRabais(Produit produits[], int size) {
	//TODO: Impl�menter cette fonction
}

/*
* Fonction servant � afficher la liste des produits disponibles � vendre.
*/
void afficherProduits(Produit produits[], int size) {
	cout << "----------------------------------------------------------------------------------------------------" << endl;
	cout << "|                                      Liste des produits                                          | " << endl;
	cout << "----------------------------------------------------------------------------------------------------" << endl;
	cout << "| " << setw(6) << left << "CODE" << " | " << setw(20) << left << "NOM" << " | " << setw(35) << left << "DESCRIPTION" << " | " << setw(7) << right << "VALEUR" << " | " << setw(6) << "RABAIS" << " |" << setw(8) << right << "PRIX" << " |" << endl;
	cout << "----------------------------------------------------------------------------------------------------" << endl;

	//TODO: Compl�ter cette fonction

	cout << "----------------------------------------------------------------------------------------------------" << endl << endl;

}


/*
* Fonction qui g�n�re des commandes al�atoires et qui les place dans le tableau de commandes
*/
void genererCommandes(Commande commandes[], int sizeCommandes, Produit produits[], int sizeProduits) {
	//TODO: Impl�menter cette fonction
}

void afficherCommandes(Commande commandes[], int size) {
	//TODO: Impl�menter cette fonction
}

/*
* Fonction principale du projet.  Elle a �t� programm�e par C�drik Dubogue
* et, quoique vous puissiez la modifier, vous ne devriez pas avoir � le faire.
*/
void atlasInformatique() {
	lireProduits(produits, NOMBRE_PRODUITS);
	genererRabais(produits, NOMBRE_PRODUITS);
	afficherProduits(produits, NOMBRE_PRODUITS);
	cout << "Appuyez sur ESPACE pour g�n�ner les commandes...";
	waitForSpaceKey();
	system("cls");
	genererCommandes(commandes, NOMBRE_COMMANDES, produits, NOMBRE_PRODUITS);
	afficherCommandes(commandes, NOMBRE_COMMANDES);
}

int main() {
	setlocale(LC_ALL, "");
	setlocale(LC_NUMERIC, "C");
	srand((unsigned int)time(NULL));
	atlasInformatique();
	return 0;
}